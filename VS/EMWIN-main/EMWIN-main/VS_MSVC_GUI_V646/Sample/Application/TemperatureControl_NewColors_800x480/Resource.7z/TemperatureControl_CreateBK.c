/*********************************************************************
*                SEGGER MICROCONTROLLER SYSTEME GmbH                 *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 2008         SEGGER Microcontroller Systeme GmbH        *
*                                                                    *
*        Internet: www.segger.com    Support:  support@segger.com    *
*                                                                    *
**********************************************************************

**** emWin/GSC Grafical user interface for embedded applications ****
emWin is protected by international copyright laws. Knowledge of the
source code may not be used to write a similar product. This file may
only be used in accordance with a license and should not be re-
distributed in any way. We appreciate your understanding and fairness.
----------------------------------------------------------------------
File        : WIDGET_Knob.c
Purpose     : Shows how to create a radial menu with motion support
Requirements: WindowManager - (x)
              MemoryDevices - (x)
              AntiAliasing  - (x)
              VNC-Server    - ( )
              PNG-Library   - ( )
              TrueTypeFonts - ( )
----------------------------------------------------------------------
*/

#include "DIALOG.h"
#include "LCD_SIM.h"

extern GUI_CONST_STORAGE GUI_FONT GUI_Font32B_AA4;
extern GUI_CONST_STORAGE GUI_BITMAP bmKNOB_175x175;
extern GUI_CONST_STORAGE GUI_BITMAP bmCircularGradient_w_Green;


/*********************************************************************
*
*       Defines
*
**********************************************************************
*/
//
// Set CREATE_BITMAP to 1 to create a bitmap
//
#define CREATE_BITMAP  1

//
// WIDGET IDs
//
#define ID_WINDOW_0  (GUI_ID_USER + 0x00)

#define KNOB_X0 500
#define KNOB_Y0 139

#define KNOB_OFFSET         450
#define FAN_CONTROL_X0      KNOB_X0 + 20
#define FAN_CONTROL_Y0      KNOB_Y0 + 255
#define FAN_CONTROL_SIZE_X  80
#define FAN_CONTROL_SIZE_Y  35


/*********************************************************************
*
*       Static data
*
**********************************************************************
*/

static GUI_CONST_STORAGE GUI_FONT * pFont32p = &GUI_Font32B_AA4;

/*********************************************************************
*
*       _aDialogCreate
*/
static const GUI_WIDGET_CREATE_INFO _aDialogCreate[] = {
  { WINDOW_CreateIndirect, "Window",         ID_WINDOW_0,   0,   0, 800, 480, 0, 0x0, 0 },
};

/*********************************************************************
*
*       Static code
*
**********************************************************************
*/

#define BK_COLOR   GUI_MAKE_COLOR(0x3C3C1E)
#define LIGHT_BLUE  GUI_MAKE_COLOR(0xaa7d67)
#define BLUE        GUI_MAKE_COLOR(0x855a41)
#define LEMON       GUI_MAKE_COLOR(0x00d6d3)

/*********************************************************************
*
*       _cbDialog
*/
static void _cbDialog(WM_MESSAGE * pMsg) {
  WM_HWIN hItem;
  int     NCode;
  int     Id;
  int     i;
  static GUI_MEMDEV_Handle   hMemKnob;
  static GUI_COLOR           ColorKnob        = GUI_WHITE;
  int KnobValue;
  GUI_RECT Rect;
  int xSizeKnob;
  int ySizeKnob;
  int xSizeButton;
  int ySizeButton;
  int Index;
  int Value;

  xSizeKnob = bmKNOB_175x175.XSize;
  ySizeKnob = bmKNOB_175x175.YSize;
  switch (pMsg->MsgId) {
  case WM_INIT_DIALOG:
    //
    // Initialization of 'Window'
    //
    hItem = pMsg->hWin;
    WINDOW_SetBkColor(hItem, BK_COLOR);
    break;
  case WM_PAINT:
    //
    // Draw a dark bar at very top
    //
    GUI_SetColor(GUI_WHITE);
    GUI_DrawRect(-1, 40, 800, 79);
    GUI_SetColor(LIGHT_BLUE);
    //
    // Draw text into top bar
    //
    GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER);
    GUI_GotoXY(400, 20);
    GUI_SetColor(GUI_WHITE);
    GUI_SetTextMode(GUI_TM_TRANS);
    GUI_SetFont(pFont32p);
    GUI_DispString("Temperature Control");
    //
    // Display Fan Status
    //
    GUI_SetTextAlign(GUI_TA_LEFT | GUI_TA_VCENTER);
    GUI_GotoXY(200, 60);
    GUI_SetColor(GUI_WHITE);
    GUI_SetTextMode(GUI_TM_TRANS);
    GUI_SetFont(pFont32p);
    GUI_DispString("Fan:");
    //
    // Display Temperatur
    //
    GUI_SetTextAlign(GUI_TA_LEFT | GUI_TA_VCENTER);
    GUI_GotoXY(332, 60);
    GUI_SetColor(GUI_WHITE);
    GUI_SetTextMode(GUI_TM_TRANS);
    GUI_SetFont(pFont32p);
    GUI_DispString("Temp:");
    //
    // Draw a frame around the fan control buttons
    //
    GUI_SetColor(BK_COLOR);
    GUI_AA_FillRoundedRect(FAN_CONTROL_X0 - 10, FAN_CONTROL_Y0 - 10, FAN_CONTROL_X0 + FAN_CONTROL_SIZE_X * 2 + 10 + 1, FAN_CONTROL_Y0 + FAN_CONTROL_SIZE_Y + 10, 5);
    GUI_SetColor(GUI_WHITE);
    GUI_AA_DrawRoundedRect(FAN_CONTROL_X0 - 10, FAN_CONTROL_Y0 - 10, FAN_CONTROL_X0 + FAN_CONTROL_SIZE_X * 2 + 10 + 1, FAN_CONTROL_Y0 + FAN_CONTROL_SIZE_Y + 10, 5);
    //
    // Draw text 'Fan'
    //
    GUI_SetColor(GUI_WHITE);
    GUI_SetTextMode(GUI_TM_TRANS);
    GUI_SetFont(pFont32p);
    GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER);
    GUI_DispStringAt("Fan", FAN_CONTROL_X0 + FAN_CONTROL_SIZE_X + 1, FAN_CONTROL_Y0 - 25);
    //
    // Draw a back ground for the knob and the knob itself
    //
    GUI_DrawBitmap(&bmCircularGradient_w_Green, KNOB_X0 - 3, KNOB_Y0 - 3);
    GUI_SetColor(GUI_WHITE);
    GUI_SetPenSize(2);
    GUI_AA_DrawArc(KNOB_X0 + xSizeKnob / 2 + 13, KNOB_Y0 - 1 + ySizeKnob / 2 + 14, 100, 100, 0, 360);
    GUI_AA_DrawLine(529, 308, 538, 299);
    GUI_AA_DrawLine(660, 299, 670, 309);
    GUI_SetPenSize(1);
    GUI_SetColor(BK_COLOR);
    GUI_FillRect(KNOB_X0 + 42, KNOB_Y0 + 43, KNOB_X0 + xSizeKnob - 18, KNOB_Y0 + ySizeKnob - 17);
    GUI_DrawBitmap(&bmKNOB_175x175, KNOB_X0 + 14, KNOB_Y0 + 15);
    //
    // Display text above knob
    //
    GUI_SetFont(pFont32p);
    GUI_SetColor(GUI_WHITE);
    GUI_SetTextAlign(GUI_TA_HCENTER | GUI_TA_VCENTER);
    GUI_GotoXY(KNOB_X0 + 100, KNOB_Y0 - 30);
    GUI_DispString("Temperature");
    break;
  default:
    WM_DefaultProc(pMsg);
    break;
  }
}

/*********************************************************************
*
*       Public code
*
**********************************************************************
*/
/*********************************************************************
*
*       CreateWindow
*/
WM_HWIN CreateWindow(void);
WM_HWIN CreateWindow(void) {
  WM_HWIN hWin;

  hWin = GUI_CreateDialogBox(_aDialogCreate, GUI_COUNTOF(_aDialogCreate), _cbDialog, WM_HBKWIN, 0, 0);
  return hWin;
}

/*********************************************************************
*
*       Public code
*
**********************************************************************
*/
/*********************************************************************
*
*       MainTask
*/
void MainTask(void) { 
  WM_HWIN hWin;

  GUI_Init();
  WM_SetCreateFlags(WM_CF_MEMDEV);
  hWin = CreateWindow();
#if CREATE_BITMAP
    GUI_Delay(100);
    SIM_GUI_SaveBMP("c:\\Work\\emWin\\Sample\\Application\\TemperatureControl_NewColors_800x480\\\Resource\\TemperatureControlSegger800x480.bmp");  // Store whole LCD content to given path
#else
  while (1) {
    GUI_Delay(100);
  }
#endif
}

/*************************** End of file ****************************/
